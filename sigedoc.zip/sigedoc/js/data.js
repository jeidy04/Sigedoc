const USERS={
'secretaria@live.uleam.edu.ec':{p:'Secre123',rol:'secretaria',nom:'María',ape:'Sánchez',dep:'Secretaría General',tel:'0991234567',pin:'123456'},
'autoridad@live.uleam.edu.ec':{p:'Autor123',rol:'autoridad',nom:'Carlos',ape:'Mendoza',dep:'Rectorado',tel:'0987654321',pin:'123456'},
'estudiante@live.uleam.edu.ec':{p:'Estud123',rol:'estudiante',nom:'Juan',ape:'Pérez',dep:'Ingeniería en Software',tel:'0976543210'}};
const RL={secretaria:'SECRETARIA',autoridad:'AUTORIDAD',estudiante:'Estudiante'};
const NAV={
secretaria:[['inicio','Inicio'],['documentos','Documentos'],['tramites','Trámites'],['busqueda','Búsqueda'],['notif','Notificaciones'],['config','Configuración']],
autoridad:[['inicio','Inicio'],['aprobar','Por aprobar'],['firma','Firma electrónica'],['tramites','Trámites'],['busqueda','Búsqueda'],['notif','Notificaciones'],['reportes','Reportes']],
estudiante:[['inicio','Inicio'],['solicitudes','Mis solicitudes'],['nueva','Nueva Solicitud']]};
const TT={inicio:'Panel principal',documentos:'Ingreso y digitalización de documentos',detalle:'Detalle del documento / expediente',tramites:'Gestión de trámites',busqueda:'Búsqueda y consulta documental',notif:'Notificaciones',config:'Configuración de Secretaría',aprobar:'Revisión y decisión',firma:'Firma y validación electrónica',reportes:'Reportes y estadísticas',perfil:'Mi perfil',solicitudes:'Mis solicitudes',nueva:'Nueva solicitud'};
const DEPS=['Secretaría General','Rectorado','Bienestar Estudiantil','Fac. Ciencias Sociales','Secretaría Académica','FCVT'];
let TIPOS=[['Oficio','SG-OF','5 años'],['Memorando','SG-ME','3 años'],['Resolución','SG-RE','Permanente']];
const hoy=()=>{const d=new Date();return[d.getDate(),d.getMonth()+1,d.getFullYear()].map(x=>String(x).padStart(2,'0')).join('/')};
const hm=()=>new Date().toTimeString().slice(0,5);
const iso=f=>f.split('/').reverse().join('-');
const mk=(n,a,r,t,f,e,d=0,h)=>({n,a,r,t,f,e,d,h:h||[['Recibido en Secretaría General',f+' · 08:14']],o:[]});
let C=116;const nn=()=>'OF-2026-'+(C++);
let D=[
mk('OF-2026-115','Informe de actividades','Decanato','Memorando','05/10/2026','Nuevo',0),
mk('OF-2026-114','Solicitud de certificado de egresamiento','Fac. Ciencias Sociales','Oficio','02/10/2026','En trámite',1,[['Recibido en Secretaría General','02/10/2026 · 08:14'],['Derivado a Bienestar Estudiantil','02/10/2026 · 10:02'],['En revisión','03/10/2026 · 09:40']]),
mk('OF-2026-109','Trámite de grado','Secretaría Académica','Oficio','02/10/2026','En trámite',3),
mk('OF-2026-105','Resolución H. Consejo','Rectorado','Resolución','01/10/2026','Urgente',5),
mk('RES-2026-021','Aprobación de resolución para período académico','Consejo Universitario','Resolución','05/10/2026','Por aprobar',2,[['Recibido en Secretaría','03/10/2026 · 09:15'],['Derivado a Autoridad','04/10/2026 · 11:20'],['Pendiente de decisión','05/10/2026 · 08:30']]),
mk('OF-2026-112','Resolución de Consejo','Consejo Universitario','Resolución','04/10/2026','Pendiente firma',1),
mk('OF-2026-098','Solicitud de récord académico','FCVT','Oficio','28/09/2026','Atendido',0)];
let SS=[{n:'OF-2026-114',t:'Certificado de egresamiento',f:'02/10/2026',e:'En trámite',p:2},{n:'OF-2026-088',t:'Récord académico',f:'14/09/2026',e:'Atendido',p:3},{n:'OF-2026-061',t:'Constancia de matrícula',f:'02/08/2026',e:'Atendido',p:3}];
let NT={
secretaria:[{t:'Nuevo documento asignado OF-2026-115',w:'Hace 5 minutos',k:'',r:0},{t:'El trámite OF-2026-109 vence en 1 día',w:'Hace 40 minutos',k:'v',r:0},{t:'Resolución OF-2026-112 pendiente firma',w:'Hoy 09:10',k:'f',r:0},{t:'José Zambrano derivó un documento a su bandeja',w:'Ayer 16:22',k:'',r:1},{t:'Reporte mensual de trámites generado',w:'Ayer 08:00',k:'',r:1}],
autoridad:[{t:'Nuevo documento pendiente de revisión RES-2026-021',w:'Hace 5 minutos',k:'',r:0},{t:'El trámite OF-2026-109 requiere decisión',w:'Hace 40 minutos',k:'v',r:0},{t:'Resolución OF-2026-112 pendiente firma',w:'Hoy 09:10',k:'f',r:0},{t:'Secretaría derivó un documento a su bandeja',w:'Ayer 16:22',k:'',r:1},{t:'Reporte mensual de trámites generado',w:'Ayer 08:00',k:'',r:1}],
estudiante:[{t:'Tu solicitud OF-2026-114 fue recibida',w:'02/10/2026 · El trámite ingresó correctamente al sistema.',k:'',r:0},{t:'Tu trámite fue derivado',w:'03/10/2026 · La solicitud pasó a la dependencia responsable.',k:'',r:0},{t:'Solicitud atendida',w:'14/09/2026 · Ya puedes descargar el resultado del trámite OF-2026-088.',k:'',r:0}]};
let ACT=['04/10/2026 Firmó MEM-2026-044','04/10/2026 · Aprobó OF-2026-115','03/10/2026 · Rechazó DOC-2026-019'];
const S={u:null,v:'inicio',a:null,tab:'e',flt:'t',edit:0,cfg:{hor:'08:00 - 17:00',can:'Correo institucional',pre:'SG-OF-2026-',rei:'Anual'}};
