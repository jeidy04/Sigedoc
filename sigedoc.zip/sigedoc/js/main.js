document.addEventListener('keydown',e=>{if(e.key==='Enter'&&!S.u&&$('#em'))doLogin()});
render();
