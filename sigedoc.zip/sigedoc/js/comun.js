/* Trámites (secretaría y autoridad) */
V.tramites=()=>{const r=S.u.rol,fin=/Atendido|Archivado|Firmado/;const L={e:D.filter(d=>!d.der&&!fin.test(d.e)),s:D.filter(d=>d.der),h:D.filter(d=>fin.test(d.e))}[S.tab];
const tb=[['e','Bandeja entrada'],['s','Bandeja salida'],['h','Historial']].map(t=>`<button class="${S.tab==t[0]?'on':''}" onclick="S.tab='${t[0]}';render()">${t[1]}</button>`).join('');
const act=d=>r=='secretaria'?(S.tab=='e'?`<button class="btn s g" onclick="derivar('${d.n}')">Derivar</button> `:'')+ver(d.n):(d.e=='Por aprobar'?`<button class="btn s g" onclick="go('aprobar','${d.n}')">Revisar</button>`:ver(d.n));
return `<div class="tabs">${tb}</div><div class="card"><h3>${S.tab=='e'?'Últimos documentos recibidos':S.tab=='s'?'Documentos derivados':'Historial de trámites'}</h3>${tbl(['N°','Asunto','Remitente','Días','Estado','Acción'],L.map(d=>[d.n,d.a,d.r,d.d,bd(d.e),act(d)]))}</div>`};

/* Búsqueda */
V.busqueda=()=>`<div class="card"><div class="cards">${F('kw','Palabra clave','',{p:'asunto, remitente'})}${SEL('bt','Tipo de documento',TIPOS.map(t=>t[0]),'','Todos')}${F('d1','Desde','',{t:'date'})}${F('d2','Hasta','',{t:'date'})}</div><button class="btn" onclick="buscar()">Buscar</button></div><div class="card" id="res">${resBus(D)}</div>`;
const resBus=L=>`<h3>Resultados (${L.length})</h3>${tbl(['N°','Asunto','Tipo','Fecha','Estado',''],L.map(d=>[d.n,d.a,d.t,d.f,bd(d.e),ver(d.n)]))}`;
function buscar(){if(!val({d2:[v=>!v||!$('#d1').value||v>=$('#d1').value,'La fecha final debe ser igual o posterior a la inicial']}))return;
const k=$('#kw').value.trim().toLowerCase(),t=$('#bt').value,a=$('#d1').value,b=$('#d2').value;
$('#res').innerHTML=resBus(D.filter(d=>(!k||(d.a+d.r+d.n).toLowerCase().includes(k))&&(!t||d.t==t)&&(!a||iso(d.f)>=a)&&(!b||iso(d.f)<=b)))}

/* Notificaciones */
V.notif=()=>{const L=NT[S.u.rol],fl=S.flt,F2=L.filter(x=>fl=='t'||(fl=='n'&&!x.r)||x.k==fl);const st=S.u.rol=='estudiante';
const tb=[['t','Todas ('+L.length+')'],['n','No leídas ('+L.filter(x=>!x.r).length+')'],['v','Vencimientos'],['f','Firmas pendientes']].map(t=>`<button class="${fl==t[0]?'on':''}" onclick="S.flt='${t[0]}';render()">${t[1]}</button>`).join('');
return (st?'':`<div class="tabs">${tb}</div>`)+(F2.map(x=>`<div class="nt ${x.r?'':'u'}" onclick="NT.${S.u.rol}[${L.indexOf(x)}].r=1;render()"><b>${x.t}</b><div class="m">${x.w}</div></div>`).join('')||'<p class="m">No hay notificaciones en esta categoría.</p>')+(st?`<button class="btn" onclick="go('inicio')">← Volver al inicio</button>`:'')};

/* PERFIL (todos los roles) */
V.perfil=()=>{const u=S.u,x=S.edit?'':'disabled',st=u.rol=='estudiante';return `<div class="card" style="max-width:560px"><a class="lnk" onclick="logout()">Cerrar sesión</a><img id="ph" class="av" alt="" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 70 70'%3E%3Crect width='70' height='70' fill='%23dde3ec'/%3E%3Ccircle cx='35' cy='27' r='12' fill='%23888'/%3E%3Cellipse cx='35' cy='62' rx='22' ry='18' fill='%23888'/%3E%3C/svg%3E"><label>Cambiar foto (JPG o PNG, máx. 2 MB)<input id="ft" type="file" accept=".jpg,.jpeg,.png" onchange="foto(this)"></label>
${F('pn','Nombres',u.nom,{x})}${F('pa','Apellidos',u.ape,{x})}${F('pc','Correo institucional',u.em,{x:'disabled'})}${F('pt','Teléfono',u.tel,{x,p:'09XXXXXXXX'})}
${st?F('pd','Carrera',u.dep,{x:'disabled'})+F('pl','Nivel / Código','4to nivel · Est-00456',{x:'disabled'}):F('pd','Dependencia',u.dep,{x:'disabled'})+F('pl','Rol',RL[u.rol][0]+RL[u.rol].slice(1).toLowerCase(),{x:'disabled'})}
<p class="m">${st?'Los datos académicos se toman del registro institucional.':'La dependencia y el rol los asigna el Administrador.'}</p>
<h3 style="color:var(--b)">Seguridad de la cuenta</h3>${F('p0','Contraseña actual','',{t:'password',x})}${F('p1','Nueva contraseña','',{t:'password',x})}${F('p2','Confirmar contraseña','',{t:'password',x})}
<div style="margin-top:12px">${S.edit?`<button class="btn" onclick="savePerfil()">Guardar cambios</button><button class="btn g" onclick="go('perfil')">Cancelar</button>`:`<button class="btn" onclick="S.edit=1;render()">Editar información</button>`}</div></div>`};
function foto(el){if(!fok(el,/\.(jpe?g|png)$/i,2)){toast('La foto debe ser JPG o PNG de máximo 2 MB');el.value='';return}const f=el.files[0];if(f)$('#ph').src=URL.createObjectURL(f)}
function savePerfil(){const R={pn:[v=>/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,}$/.test(v),'Solo letras, mínimo 2 caracteres'],pa:[v=>/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,}$/.test(v),'Solo letras, mínimo 2 caracteres'],pt:[v=>/^09\d{8}$/.test(v),'Debe tener 10 dígitos y empezar con 09']};
if($('#p0').value||$('#p1').value||$('#p2').value){R.p0=[v=>v===S.u.p,'La contraseña actual no coincide'];R.p1=[v=>/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(v),'Mínimo 8 caracteres con letras y números'];R.p2=[v=>v===$('#p1').value,'Las contraseñas no coinciden']}
if(!val(R))return;Object.assign(S.u,{nom:$('#pn').value,ape:$('#pa').value,tel:$('#pt').value});if(R.p0){S.u.p=$('#p1').value;USERS[S.u.em].p=S.u.p}toast('Perfil actualizado');go('perfil')}

