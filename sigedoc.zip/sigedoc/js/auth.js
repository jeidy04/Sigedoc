/* LOGIN y estructura general */
function login(){return `<div class="lg"><div class="lgc"><img class="lgl" src="img/logo-uleam.png" alt="Logo Uleam"><h1 class="ti">Sistema de Gestión Documental (sigedoc)</h1><h3 style="text-align:center;margin:0">Acceso al Sistema</h3>${F('em','Usuario institucional:','',{p:'correo institucional',t:'email',x:'autocomplete="username"'})}${F('pw','Contraseña:','',{p:'••••••••',t:'password',x:'autocomplete="current-password"'})}<div id="lerr" class="alerta" hidden></div><button class="btn" style="width:100%;margin-top:14px" onclick="doLogin()">Iniciar sesión</button></div></div>`}
function doLogin(){
const box=$('#lerr');box.hidden=true;
if(!val({
em:[v=>/^[\w.+-]+@(live\.)?uleam\.edu\.ec$/i.test(v),v=>v?'Correo no válido. Use su correo institucional (@live.uleam.edu.ec)':'Ingrese su correo institucional'],
pw:[v=>v.length>=6,v=>v?'La contraseña debe tener al menos 6 caracteres':'Ingrese su contraseña']}))return;
const em=$('#em').value.trim().toLowerCase(),u=USERS[em];
if(!u||u.p!==$('#pw').value){$('#em').classList.add('bad');$('#pw').classList.add('bad');box.textContent='Usuario o contraseña incorrectos. Verifique sus datos e intente de nuevo.';box.hidden=false;return}
S.u={...u,em};go('inicio')}
function logout(){S.u=null;S.v='inicio';render()}
function shell(c){const r=S.u.rol,N=NAV[r],t=TT[S.v]||'',on=k=>S.v==k||(S.v=='detalle'&&k=='documentos')?'on':'';
const who=`<button class="who" onclick="go('perfil')">${RL[r]} ☺</button>`,lg='<img class="lgs" src="img/logo-uleam.png" alt="Uleam">';
if(r=='estudiante')return `<div class="nav">${lg}${N.map(n=>`<a class="${S.v==n[0]?'on':''}" onclick="go('${n[0]}')">${n[1]}</a>`).join('')}${who}</div><div class="main"><div class="top"><h2>${t}</h2></div>${c}</div>`;
return `<div class="app"><div class="sb">${lg}${N.map(n=>`<button class="${on(n[0])}" onclick="go('${n[0]}')">${n[1]}</button>`).join('')}</div><div class="main"><div class="top"><h2>${t}</h2>${who}</div>${c}</div></div>`}
